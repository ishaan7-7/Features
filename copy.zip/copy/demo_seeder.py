"""
Demo Seeder — pre-populates 15 days of data across all pipeline layers.

Generates data for all enabled vehicles and modules defined in:
  config/pipeline_config.json   (which modules, weights, penalties)
  replay/config/replay_config.json (which vehicle sims to seed)

Run once before a demo presentation. Expected runtime: 20-40 min on CPU.
Usage:  python tools/demo_seeder.py [--days 15]

After this script completes, run:  python tools/start_demo.py
Then start services normally and run the replay notebook.
"""

import sys
import os
import json
import pickle
import hashlib
import uuid
import shutil
import argparse
import time
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ProcessPoolExecutor, as_completed

import pandas as pd
import pyarrow as pa
from deltalake import write_deltalake

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "inference_service"))

BRONZE_ROOT      = ROOT / "data" / "delta" / "bronze"
SILVER_ROOT      = ROOT / "data" / "delta" / "silver"
GOLD_ROOT        = ROOT / "data" / "delta" / "gold" / "vehicle_health"
ALERTS_ROOT      = ROOT / "data" / "delta" / "gold" / "alerts"
VEHICLES_ROOT    = ROOT / "data" / "vehicles"
INF_STATE_DIR    = ROOT / "inference_service" / "state"
GOLD_STATE_DIR   = ROOT / "gold_service" / "state"
ALERTS_STATE_DIR = ROOT / "alerts_service" / "state"
REPLAY_CKPT_DIR  = ROOT / "replay" / "checkpoints"
WRITER_CKPT_DIR  = ROOT / "data" / "checkpoints" / "writer"
CONTRACTS_FILE   = ROOT / "contracts" / "master.json"
PIPELINE_CFG     = ROOT / "config" / "pipeline_config.json"
REPLAY_CFG       = ROOT / "replay" / "config" / "replay_config.json"


def load_pipeline_config() -> dict:
    return json.loads(PIPELINE_CFG.read_text())


def load_replay_config() -> dict:
    return json.loads(REPLAY_CFG.read_text())


def load_contracts() -> dict:
    return json.loads(CONTRACTS_FILE.read_text())


def find_csv(sim_dir: Path, module: str, contracts: dict) -> Path | None:
    pattern = contracts["modules"][module]["file_pattern"]
    matches = list(sim_dir.glob(pattern))
    return matches[0] if len(matches) == 1 else None


def make_row_hash(sim_id: str, module: str, timestamp: str) -> str:
    return hashlib.sha256(f"{sim_id}|{module}|{timestamp}".encode()).hexdigest()


def ts_to_iso(ts) -> str:
    if hasattr(ts, "isoformat"):
        return ts.isoformat() if ts.tzinfo else ts.isoformat() + "+00:00"
    return str(ts)


class SeedStateManager:
    """
    Drop-in replacement for inference_service StateManager.
    Holds all state in memory during seeding; caller writes it to disk.
    """

    def __init__(self, module: str):
        self.module = module
        self.checkpoints: dict = {}
        self.ml_state: dict = {}

    def get_last_timestamp(self, sim_id: str) -> str:
        return self.checkpoints.get(f"{sim_id}_{self.module}", "1970-01-01T00:00:00.000Z")

    def update_checkpoint(self, sim_id: str, timestamp_str: str) -> None:
        self.checkpoints[f"{sim_id}_{self.module}"] = timestamp_str

    def get_ml_state(self, sim_id: str) -> dict:
        key = f"{sim_id}_{self.module}"
        if key not in self.ml_state:
            self.ml_state[key] = {
                "ema_error": 0.0,
                "persistence_counter": 0,
                "last_window_data": None,
            }
        return self.ml_state[key]

    def update_ml_state(
        self, sim_id: str, ema_error: float, persistence_counter: int, last_window_data
    ) -> None:
        self.ml_state[f"{sim_id}_{self.module}"] = {
            "ema_error": float(ema_error),
            "persistence_counter": int(persistence_counter),
            "last_window_data": last_window_data,
        }

    def log_alert(self, sim_id: str, level: str, message: str) -> None:
        pass


def _build_alert_payload(sim_id: str, module: str, state: dict, status: str, end_ts: str = None) -> dict:
    sorted_feats = sorted(state["accumulated_features"].items(), key=lambda x: x[1], reverse=True)[:10]
    return {
        "alert_id":           state["alert_id"],
        "source_id":          sim_id,
        "module":             module,
        "status":             status,
        "alert_start_ts":     state["start_ts"],
        "alert_end_ts":       end_ts,
        "peak_anomaly_ts":    state["peak_ts"],
        "max_composite_score": round(float(state["max_score"]), 4),
        "top_10_features":    json.dumps({k: round(float(v), 4) for k, v in sorted_feats}),
        "last_updated_ts":    datetime.now(timezone.utc).isoformat(),
    }


def seed_module(module: str, vehicles: list, cutoff_iso: str) -> dict:
    """
    Phase-1 worker: generates Bronze + Silver for one module, all vehicles.
    Runs in a separate process — self-contained, no shared state.
    Returns serialisable summary consumed by the main process for Phase 2+3.
    """
    sys.path.insert(0, str(ROOT / "inference_service"))

    from src.ml_engine import MLEngine

    pipeline_cfg = load_pipeline_config()
    contracts    = load_contracts()
    cutoff_ts    = pd.Timestamp(cutoff_iso, tz="UTC")

    print(f"[{module.upper()}] Starting — {len(vehicles)} vehicles, cutoff {cutoff_iso}")
    t0 = time.time()

    bronze_frames  = []
    replay_ckpts   = {}

    for sim_id in vehicles:
        sim_dir  = VEHICLES_ROOT / sim_id
        csv_path = find_csv(sim_dir, module, contracts)
        if csv_path is None:
            print(f"[{module.upper()}] WARNING: no CSV for {sim_id} — skipped")
            continue

        df = pd.read_csv(csv_path)
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)

        df_seed  = df[df["timestamp"] < cutoff_ts].copy().reset_index(drop=True)
        df_full  = df.reset_index(drop=True)

        if df_seed.empty:
            print(f"[{module.upper()}] WARNING: {sim_id} has no rows before cutoff — skipped")
            continue

        df_seed["source_id"] = sim_id
        df_seed["ingest_ts"] = df_seed["timestamp"].dt.strftime("%Y-%m-%dT%H:%M:%S.%f+00:00")
        df_seed["writer_ts"] = df_seed["ingest_ts"]
        df_seed["row_hash"]  = [
            make_row_hash(sim_id, module, row["ingest_ts"])
            for _, row in df_seed.iterrows()
        ]
        df_seed["timestamp"] = df_seed["timestamp"].dt.strftime("%Y-%m-%dT%H:%M:%S.%f+00:00")
        df_seed = df_seed.drop(columns=["date"], errors="ignore")

        bronze_frames.append(df_seed)

        last_seed_idx = len(df_full[df_full["timestamp"] < cutoff_ts]) - 1
        last_hash = make_row_hash(
            sim_id, module,
            df_seed.iloc[-1]["ingest_ts"]
        )
        replay_ckpts[sim_id] = {
            "source_id":     f"{sim_id}_{module}",
            "last_row_index": int(last_seed_idx),
            "last_row_hash":  last_hash,
            "updated_at":     datetime.now(timezone.utc).isoformat(),
        }

    if not bronze_frames:
        print(f"[{module.upper()}] No Bronze data produced — aborting module")
        return {"module": module, "error": "no_data"}

    bronze_df   = pd.concat(bronze_frames, ignore_index=True)
    bronze_path = str(BRONZE_ROOT / module)
    os.makedirs(bronze_path, exist_ok=True)
    write_deltalake(bronze_path, bronze_df, mode="overwrite", schema_mode="overwrite")
    print(f"[{module.upper()}] Bronze written: {len(bronze_df)} rows")

    REPLAY_CKPT_DIR.mkdir(parents=True, exist_ok=True)
    for sim_id, ckpt in replay_ckpts.items():
        (REPLAY_CKPT_DIR / f"{sim_id}_{module}.json").write_text(json.dumps(ckpt))
    print(f"[{module.upper()}] Replay checkpoints written")

    seed_state = SeedStateManager(module)
    ml         = MLEngine(seed_state, module)

    silver_frames = []
    BATCH_SIZE = 60

    for sim_id in vehicles:
        sim_bronze = bronze_df[bronze_df["source_id"] == sim_id].copy()
        if sim_bronze.empty:
            continue

        sim_bronze = sim_bronze.reset_index(drop=True)
        sim_silver = []

        for start in range(0, len(sim_bronze), BATCH_SIZE):
            batch = sim_bronze.iloc[start : start + BATCH_SIZE].copy()
            try:
                out = ml.process_batch(batch, sim_id)
                if not out.empty:
                    out["inference_ts"] = batch["ingest_ts"].values[: len(out)]
                    sim_silver.append(out)
            except Exception as exc:
                print(f"[{module.upper()}] Inference error {sim_id} batch {start}: {exc}")

        if sim_silver:
            silver_frames.append(pd.concat(sim_silver, ignore_index=True))
            seed_state.update_checkpoint(sim_id, str(sim_bronze["ingest_ts"].max()))

    if not silver_frames:
        print(f"[{module.upper()}] No Silver data produced")
        return {"module": module, "error": "no_silver"}

    silver_df   = pd.concat(silver_frames, ignore_index=True)
    silver_path = str(SILVER_ROOT / module)
    os.makedirs(silver_path, exist_ok=True)
    write_deltalake(silver_path, silver_df, mode="overwrite", schema_mode="overwrite")
    print(f"[{module.upper()}] Silver written: {len(silver_df)} rows")

    INF_STATE_DIR.mkdir(parents=True, exist_ok=True)
    (INF_STATE_DIR / f"checkpoints_{module}.json").write_text(
        json.dumps(seed_state.checkpoints, indent=2)
    )
    with open(INF_STATE_DIR / f"ml_state_{module}.pkl", "wb") as fh:
        pickle.dump(seed_state.ml_state, fh)

    elapsed = round(time.time() - t0, 1)
    print(f"[{module.upper()}] Complete in {elapsed}s — Bronze {len(bronze_df)}, Silver {len(silver_df)}")
    return {"module": module, "silver_rows": len(silver_df), "elapsed": elapsed}


def seed_gold_and_alerts(pipeline_cfg: dict) -> None:
    """
    Phase 2 + 3 (sequential): aggregates all Silver data into Gold health records
    and runs the alert leaky-bucket state machine to produce Alerts records.
    """
    enabled_modules = pipeline_cfg["enabled_modules"]
    raw_weights     = {m: pipeline_cfg["module_weights"].get(m, 0.0) for m in enabled_modules}
    w_sum           = sum(raw_weights.values())
    norm_weights    = {m: raw_weights[m] / w_sum for m in enabled_modules}
    penalties       = pipeline_cfg["tier_1_penalties"]

    print("\n[GOLD] Loading Silver data from all modules...")
    silver_dfs: dict[str, pd.DataFrame] = {}
    for module in enabled_modules:
        silver_path = SILVER_ROOT / module
        if not silver_path.exists():
            print(f"[GOLD] WARNING: Silver/{module} not found — skipped in Gold")
            continue
        try:
            from deltalake import DeltaTable
            df = DeltaTable(str(silver_path)).to_pandas()
            df["module_name"] = module
            silver_dfs[module] = df
            print(f"[GOLD] Loaded Silver/{module}: {len(df)} rows")
        except Exception as exc:
            print(f"[GOLD] Failed to load Silver/{module}: {exc}")

    if not silver_dfs:
        print("[GOLD] No Silver data available — skipping Gold and Alerts")
        return

    all_silver = pd.concat(silver_dfs.values(), ignore_index=True)
    all_silver["timestamp"] = pd.to_datetime(all_silver["timestamp"], utc=True)
    all_silver = all_silver.sort_values("timestamp", ascending=True)

    all_silver["window_ts"] = all_silver["timestamp"].dt.floor("300s")

    vehicle_cache: dict = {}
    gold_records:  list = []

    print("[GOLD] Running 5-minute window aggregation...")
    for (sim_id, window_ts), group in all_silver.groupby(["source_id", "window_ts"]):
        if sim_id not in vehicle_cache:
            vehicle_cache[sim_id] = {m: {"health": 100.0, "feats": "{}"} for m in enabled_modules}

        for _, row in group.iterrows():
            mod = row["module_name"]
            if mod in enabled_modules:
                vehicle_cache[sim_id][mod] = {
                    "health": float(row["health_score"]),
                    "feats":  str(row.get("top_features", "{}")),
                }

        total_health = 0.0
        contribs     = {}
        feature_pool = []

        for mod, w in norm_weights.items():
            mod_data = vehicle_cache[sim_id].get(mod, {"health": 100.0, "feats": "{}"})
            h        = mod_data["health"]
            total_health += h * w
            contribs[f"{mod}_contrib"] = round(h, 2)
            try:
                for fn, fv in json.loads(mod_data["feats"]).items():
                    feature_pool.append({"feature": fn, "impact": fv * w})
            except Exception:
                pass

        for pen_mod, threshold in penalties.items():
            ck = f"{pen_mod}_contrib"
            if ck in contribs and contribs[ck] < threshold:
                total_health = min(total_health, contribs[ck])

        feature_pool.sort(key=lambda x: x["impact"], reverse=True)
        top_5 = {f["feature"]: round(f["impact"], 4) for f in feature_pool[:5]}

        gold_records.append({
            "source_id":            sim_id,
            "gold_window_ts":       str(window_ts),
            "vehicle_health_score": round(total_health, 2),
            **contribs,
            "top_5_features":       json.dumps(top_5),
            "gold_write_ts":        str(window_ts),
        })

    if gold_records:
        gold_df = pd.DataFrame(gold_records)
        GOLD_ROOT.mkdir(parents=True, exist_ok=True)
        write_deltalake(str(GOLD_ROOT), gold_df, mode="overwrite", schema_mode="overwrite")
        print(f"[GOLD] Written: {len(gold_df)} Gold health records")

    max_inf_ts: dict = {}
    for module, df in silver_dfs.items():
        if "inference_ts" in df.columns and not df.empty:
            max_inf_ts[module] = str(df["inference_ts"].max())

    GOLD_STATE_DIR.mkdir(parents=True, exist_ok=True)
    (GOLD_STATE_DIR / "checkpoints.json").write_text(json.dumps(max_inf_ts, indent=2))
    with open(GOLD_STATE_DIR / "vehicle_cache.pkl", "wb") as fh:
        pickle.dump(vehicle_cache, fh)
    print(f"[GOLD] State saved — checkpoints: {max_inf_ts}")

    print("\n[ALERTS] Running leaky-bucket state machine...")
    SCORE_DELTAS = {"CRITICAL": 20, "WARNING": 5, "NORMAL": -10}
    MAX_SCORE, MIN_SCORE = 100, 0

    alert_state_cache: dict = {}
    alert_records:     dict = {}

    for _, row in all_silver.iterrows():
        sim_id  = row["source_id"]
        module  = row["module_name"]
        key     = f"{sim_id}_{module}"

        if key not in alert_state_cache:
            alert_state_cache[key] = {
                "phase": "IDLE", "fault_score": 0, "alert_id": None,
                "start_ts": None, "accumulated_features": {},
                "max_score": 0.0, "peak_ts": None,
            }

        state    = alert_state_cache[key]
        severity = row.get("severity", "NORMAL")
        comp     = float(row.get("composite_score", 0.0))
        ts       = str(row["timestamp"])

        try:
            feats = json.loads(row.get("top_features", "{}"))
        except Exception:
            feats = {}

        state["fault_score"] = max(
            MIN_SCORE,
            min(MAX_SCORE, state["fault_score"] + SCORE_DELTAS.get(severity, 0)),
        )

        if state["fault_score"] > 0:
            for fn, fv in feats.items():
                state["accumulated_features"][fn] = (
                    state["accumulated_features"].get(fn, 0.0) + fv
                )
            if state["phase"] == "IDLE" and state["start_ts"] is None:
                state["start_ts"] = ts
            if comp > state["max_score"]:
                state["max_score"] = comp
                state["peak_ts"]   = ts

        payload = None

        if state["phase"] == "IDLE":
            if state["fault_score"] >= MAX_SCORE:
                state["phase"]    = "ACTIVE"
                state["alert_id"] = str(uuid.uuid4())
                payload = _build_alert_payload(sim_id, module, state, "OPEN")
            elif state["fault_score"] == 0:
                state.update({"start_ts": None, "accumulated_features": {},
                               "max_score": 0.0, "peak_ts": None, "alert_id": None})

        elif state["phase"] == "ACTIVE":
            if state["fault_score"] <= MIN_SCORE:
                payload = _build_alert_payload(sim_id, module, state, "CLOSED", end_ts=ts)
                state["phase"] = "IDLE"
                state.update({"start_ts": None, "accumulated_features": {},
                               "max_score": 0.0, "peak_ts": None, "alert_id": None})
            else:
                payload = _build_alert_payload(sim_id, module, state, "OPEN")

        if payload:
            alert_records[payload["alert_id"]] = payload

    ALERTS_STATE_DIR.mkdir(parents=True, exist_ok=True)
    (ALERTS_STATE_DIR / "checkpoints.json").write_text(json.dumps(max_inf_ts, indent=2))
    with open(ALERTS_STATE_DIR / "alert_state_cache.pkl", "wb") as fh:
        pickle.dump(alert_state_cache, fh)

    if alert_records:
        ALERT_SCHEMA = pa.schema([
            ("alert_id",            pa.string()),
            ("source_id",           pa.string()),
            ("module",              pa.string()),
            ("status",              pa.string()),
            ("alert_start_ts",      pa.string()),
            ("alert_end_ts",        pa.string()),
            ("peak_anomaly_ts",     pa.string()),
            ("max_composite_score", pa.float64()),
            ("top_10_features",     pa.string()),
            ("last_updated_ts",     pa.string()),
        ])
        alerts_df = pd.DataFrame(list(alert_records.values()))
        ALERTS_ROOT.mkdir(parents=True, exist_ok=True)
        write_deltalake(
            str(ALERTS_ROOT),
            pa.Table.from_pandas(alerts_df, schema=ALERT_SCHEMA),
            mode="overwrite",
        )
        print(f"[ALERTS] Written: {len(alert_records)} alert records")
    else:
        print("[ALERTS] No alerts fired in 15-day window")

    print("[ALERTS] State saved")


def clear_writer_checkpoints() -> None:
    if WRITER_CKPT_DIR.exists():
        shutil.rmtree(WRITER_CKPT_DIR)
    WRITER_CKPT_DIR.mkdir(parents=True, exist_ok=True)
    print("[WRITER] Spark checkpoints cleared — Writer will start fresh from Kafka offset 0")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--days", type=int, default=15,
                        help="Number of days to pre-seed (default: 15)")
    args = parser.parse_args()

    pipeline_cfg = load_pipeline_config()
    replay_cfg   = load_replay_config()

    enabled_modules = pipeline_cfg["enabled_modules"]
    vehicles        = replay_cfg["enabled_sims"]

    cutoff_iso = (pd.Timestamp("2024-07-05", tz="UTC") + pd.Timedelta(days=args.days)).isoformat()

    print("=" * 60)
    print(f"DEMO SEEDER — {args.days}-day pre-seed")
    print(f"Modules  : {enabled_modules}")
    print(f"Vehicles : {vehicles}")
    print(f"Cutoff   : {cutoff_iso}")
    print("=" * 60)

    t_start = time.time()

    with ProcessPoolExecutor(max_workers=len(enabled_modules)) as pool:
        futures = {
            pool.submit(seed_module, module, vehicles, cutoff_iso): module
            for module in enabled_modules
        }
        results = {}
        for future in as_completed(futures):
            module = futures[future]
            try:
                results[module] = future.result()
            except Exception as exc:
                print(f"[{module.upper()}] FAILED: {exc}")
                results[module] = {"module": module, "error": str(exc)}

    errors = [r for r in results.values() if "error" in r]
    if errors:
        print(f"\nWARNING: {len(errors)} module(s) had errors: {[e['module'] for e in errors]}")
        print("Gold and Alerts will run on available Silver data only.")

    seed_gold_and_alerts(pipeline_cfg)

    clear_writer_checkpoints()

    elapsed_total = round(time.time() - t_start, 1)
    print("\n" + "=" * 60)
    print(f"SEEDING COMPLETE — total time: {elapsed_total}s")
    print("Next step: python tools/start_demo.py")
    print("=" * 60)


if __name__ == "__main__":
    main()
