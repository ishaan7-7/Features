"""
Demo Start Orchestrator.

Run this INSTEAD of the hard-reset flow when presenting.
It validates seed data, resets Kafka topics to offset-0, and clears
the Spark Writer checkpoint so streaming picks up cleanly from Day 16.

Usage:  python tools/start_demo.py

After this completes, start services via run.py as normal,
then run the replay notebook — it will begin from Day 16 automatically.
"""

import sys
import os
import json
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

KAFKA_BIN        = Path(r"C:\kafka\bin\windows")
WRITER_CKPT_DIR  = ROOT / "data" / "checkpoints" / "writer"
REPLAY_CFG_FILE  = ROOT / "replay" / "config" / "replay_config.json"
PIPELINE_CFG     = ROOT / "config" / "pipeline_config.json"

KAFKA_TOPICS = [
    "telemetry.battery",
    "telemetry.body",
    "telemetry.engine",
    "telemetry.transmission",
    "telemetry.tyre",
]

REQUIRED_SEED_PATHS = [
    ROOT / "data"                   / "delta" / "bronze",
    ROOT / "data"                   / "delta" / "silver",
    ROOT / "data"                   / "delta" / "gold" / "vehicle_health",
    ROOT / "inference_service"      / "state",
    ROOT / "gold_service"           / "state" / "checkpoints.json",
    ROOT / "alerts_service"         / "state" / "checkpoints.json",
]


def verify_seed() -> bool:
    missing = [p for p in REQUIRED_SEED_PATHS if not p.exists()]
    if missing:
        print("ERROR: Seed data incomplete. Run   python tools/demo_seeder.py   first.")
        for m in missing:
            print(f"  Missing: {m}")
        return False

    pipeline_cfg     = json.loads(PIPELINE_CFG.read_text())
    enabled_modules  = pipeline_cfg["enabled_modules"]
    replay_cfg       = json.loads(REPLAY_CFG_FILE.read_text())
    vehicles         = replay_cfg["enabled_sims"]

    for module in enabled_modules:
        bronze_path = ROOT / "data" / "delta" / "bronze" / module
        silver_path = ROOT / "data" / "delta" / "silver" / module
        if not bronze_path.exists():
            print(f"ERROR: Bronze/{module} missing — run seeder")
            return False
        if not silver_path.exists():
            print(f"ERROR: Silver/{module} missing — run seeder")
            return False

    replay_ckpt_dir = ROOT / "replay" / "checkpoints"
    for sim_id in vehicles:
        for module in enabled_modules:
            ckpt = replay_ckpt_dir / f"{sim_id}_{module}.json"
            if not ckpt.exists():
                print(f"ERROR: Replay checkpoint missing: {ckpt.name} — run seeder")
                return False

    return True


def reset_kafka_topics() -> None:
    print("Resetting Kafka topics (delete + recreate for clean offset-0)...")

    for topic in KAFKA_TOPICS:
        cmd = (
            f'"{KAFKA_BIN / "kafka-topics.bat"}" --delete '
            f"--topic {topic} --bootstrap-server localhost:9092"
        )
        subprocess.run(cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    print("  Topics deleted — waiting 5s for Kafka to settle...")
    time.sleep(5)

    for topic in KAFKA_TOPICS:
        cmd = (
            f'"{KAFKA_BIN / "kafka-topics.bat"}" --create '
            f"--topic {topic} --bootstrap-server localhost:9092 "
            f"--partitions 6 --replication-factor 1"
        )
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"  WARNING: Could not recreate topic {topic}: {result.stderr.strip()}")
        else:
            print(f"  Created: {topic}")


def clear_writer_checkpoints() -> None:
    if WRITER_CKPT_DIR.exists():
        shutil.rmtree(WRITER_CKPT_DIR)
    WRITER_CKPT_DIR.mkdir(parents=True, exist_ok=True)
    print("Spark Writer checkpoints cleared.")


def print_summary() -> None:
    pipeline_cfg = json.loads(PIPELINE_CFG.read_text())
    replay_cfg   = json.loads(REPLAY_CFG_FILE.read_text())
    gold_ckpt    = ROOT / "gold_service" / "state" / "checkpoints.json"
    gold_ts      = json.loads(gold_ckpt.read_text()) if gold_ckpt.exists() else {}

    print()
    print("=" * 60)
    print("DEMO MODE READY")
    print("=" * 60)
    print(f"  Vehicles : {replay_cfg['enabled_sims']}")
    print(f"  Modules  : {pipeline_cfg['enabled_modules']}")
    print(f"  Gold checkpoints (services resume from here):")
    for mod, ts in gold_ts.items():
        print(f"    {mod:<15}: {ts}")
    print()
    print("  Next steps:")
    print("  1. Start services via run.py (skip hard-reset)")
    print("  2. Open replay notebook")
    print("  3. Run   service.start(reset=False)")
    print("  4. Dashboard shows 15 days immediately; new data streams in")
    print("=" * 60)


def main() -> None:
    print("=" * 60)
    print("DEMO START SEQUENCE")
    print("=" * 60)

    if not verify_seed():
        sys.exit(1)

    print("Seed data verified.")

    reset_kafka_topics()
    clear_writer_checkpoints()

    print_summary()


if __name__ == "__main__":
    main()
